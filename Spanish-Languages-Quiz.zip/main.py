import random
from random import choice

import json


arr = json.loads("languages.json")
answers=[]