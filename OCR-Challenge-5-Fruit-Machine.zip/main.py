from random import randint
from time import sleep
import os

def cls():
    os.system('cls' if os.name=='nt' else 'clear')

fruit_symbols = ["🍒", "🔔", "🍋", "🍊", "⭐", "💀"]

balance = 1

def random_fruit():
   return fruit_symbols[randint(0, len(fruit_symbols) - 1)]


def roll_anim(duration):
   for i in range(duration):
      print(random_fruit(), random_fruit(), random_fruit(), end="\r")
      sleep(0.2)


def roll_machine():
   roll_anim(10)
   result = [random_fruit(), random_fruit(), random_fruit()]
   print(result[0], result[1], result[2])
   return result

def get_winnings(roll, balance):
   if roll[0] == "🔔" and roll[1] == "🔔" and roll[2] == "🔔":
      return 5.0
   elif roll[0] == "💀" and roll[1] == "💀" and roll[2] == "💀":
      return -balance
   elif roll[0] == roll[1] and roll[1] == roll[2]:
      return 1.0
      
   for fruit_a in roll:
      for fruit_b in roll[1:]:
         if fruit_a == "💀" and fruit_b == "💀":
            return -1
         elif fruit_a == fruit_b:
            return 0.5
   
   return 0.0

while balance > 0:
   cls()
   balance = round(balance, 2)
   print("Balance: " + str(balance))
   choice = input("Roll [20p] (r) / Quit (q): ")
   if choice == "r":
      balance -= 0.2
      roll = roll_machine()
      winnings = get_winnings(roll, balance)
      print("You won: " + str(winnings))
      balance += float(winnings)
      print("New balance: " + str(round(balance, 2)))
      sleep(2)
   else:
      break

print("Game over!")
